<!-----------Footer----------------->
<footer class="tv-footer" style="background-image: url('images/footer-bg.jpg')">
    <div class="tv-footer-copyrights">
        <div class="container">
            <div class="flex-box-view-one">
                <div class="tv-footer-logo">
                    <a href="/"><h2><b style="color:#6bbb24">Essay</b><b style="color:#1583e9">Falcon Blog.</b></h2></a>
                </div>
                <div class="copyright">
                    <p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> <a href=".com"><b style="color:#6bbb24">Essay</b><b style="color:#1583e9">Falcon</b>.</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-----------End----------------->