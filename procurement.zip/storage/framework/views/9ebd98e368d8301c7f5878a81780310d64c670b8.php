<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Procurement">
    <meta name="author" content="Procurement">
    <meta name="keywords" content="Procurement">
	<link rel="icon" href="<?php echo e(asset('img/house-of-prayer-ministries-logo.png')); ?>" type="icon">

    <!-- Title Page-->
    <title>Procurement || Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('admin/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo e(asset('admin/css/theme.css')); ?>" rel="stylesheet" media="all">
    

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="<?php echo e(asset('images/EssayFalcon.png')); ?>" alt="Procurement" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                            <ul class="list-unstyled navbar__list">
                                <li class="active has-sub">
                                    <a class="js-arrow" href="/">
                                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>                            
                                </li>
                                <li>
                                    <a href="/quotes">
                                        <i class="fas fa-table"></i>Quotes</a>
                                </li>
                                <li>
                                    <a href="/bids">
                                        <i class="fas fa-list"></i>Bids</a>
                                </li>         
                                <?php if(Auth::user()->role->id == 1 ): ?>
                                    <li>
                                        <a href="/users">
                                            <i class="fas fa-users"></i>Users</a>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a href="/users/settings">
                                        <i class="zmdi zmdi-settings"></i>Settings</a>
                                </li> 
                            </ul>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <h4>Procurement</h4>
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="/">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>                            
                        </li>
                        <li>
                            <a href="/quotes">
                                <i class="fas fa-list"></i>Quotes</a>
                        </li>
                        <li>
                            <a href="/bids">
                                <i class="fas fa-list"></i>Bids</a>
                        </li> 
                        <?php if(Auth::user()->role->id <= 2 ): ?>
                            <li>
                                <a href="/departments">
                                    <i class="fas fa-table"></i>Departments</a>
                            </li> 
                        <?php endif; ?>       
                        <?php if(Auth::user()->role->id == 1 ): ?>
                            <li>
                                <a href="/users">
                                    <i class="fas fa-users"></i>Users</a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <a href="/users/settings">
                                <i class="zmdi zmdi-settings"></i>Settings</a>
                        </li>                        
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                
                            </form>
                            <div class="header-button">
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <?php if(!empty (Auth::user()->avatar)): ?>
                                                <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt="<?php echo e(Auth::user()->first_name); ?>" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('img/house-of-prayer-ministries-logo.png')); ?>" alt="<?php echo e(Auth::user()->first_name); ?>" />
                                            <?php endif; ?>
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo e(Auth::user()->first_name); ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                            <?php if(!empty (Auth::user()->avatar)): ?>
                                                                <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt="<?php echo e(Auth::user()->first_name); ?>" />
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('img/house-of-prayer-ministries-logo.png')); ?>" alt="<?php echo e(Auth::user()->first_name); ?>" />
                                                            <?php endif; ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo e(Auth::user()->first_name); ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo e(Auth::user()->email); ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">                                                
                                                <div class="account-dropdown__item">
                                                    <a href="/users/settings">
                                                        <i class="zmdi zmdi-settings"></i>Settings</a>
                                                </div>                                                
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="<?php echo e(route('logout')); ?>" 
                                                onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <?php echo $__env->yieldContent('content'); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> <b style="color:#6bbb24">Shiqs</b><b style="color:#1583e9"></b>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('/admin/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e(asset('/admin/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/select2/select2.min.js')); ?>"></script>

    <!-- Main JS-->
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/js/sermons.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.select2').select2();
            // $('.dateTimePicker').datetimepicker();
        });
    </script>


<script>
    function readURL(input,id) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#'+id)
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

</body>

</html>
<!-- end document-->
<?php /**PATH C:\xampp\htdocs\procurement\resources\views/layouts/dash-nav.blade.php ENDPATH**/ ?>