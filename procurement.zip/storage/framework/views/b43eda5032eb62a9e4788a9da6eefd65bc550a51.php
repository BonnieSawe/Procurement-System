<?php $__env->startSection('content'); ?>
<div class="main-content">
        <div class="section__content section__content--p30">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="overview-wrap">
                                <h2 class="title-1">Users</h2>
                                <?php if(Auth::user()->role->id <= 2 ): ?>
                                    <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addNew">
                                            <i class="fa fa-plus"></i>Add new
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                    <tr>                                                
                                                        <th>Image</th>                        
                                                        <th>Name</th>
                                                        <th>Role</th>
                                                        <th>Phone Number</th>
                                                        <?php if(Auth::user()->role->id <= 2 ): ?>
                                                            <th></th>
                                                        <?php endif; ?>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr> 
                                                            <td style="width:100px">
                                                                    <?php if(!empty($user->avatar)): ?>
                                                                        <img  src="<?php echo e(asset( $user->avatar )); ?>" alt="<?php echo e($user->first_name); ?>" class="img-responsive"/>
                                                                    <?php endif; ?>
                                                            </td>
                                                            <td><?php echo e($user->first_name.' '.$user->other_names); ?></td>
                                                            <td> <?php echo e($user->role->name); ?> </td>
                                                            <td> <?php echo e($user->phone_number1); ?> </td>
                                                            <?php if(Auth::user()->role->id <= 2 ): ?>
                                                                <td>
                                                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-<?php echo e($user->id); ?>">
                                                                        <i class="fa fa-edit"></i> Edit
                                                                    </button>
                                                                    <?php if($user->active): ?>
                                                                        <button type="button" class="btn btn-warning btn-sm" data-toggle="modal"  data-target="#deactivate-<?php echo e($user->id); ?>">
                                                                            <i class="fa fa-exclamation-triangle"></i> De-activate
                                                                        </button>
                                                                    <?php else: ?>
                                                                        
                                                                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal"  data-target="#activate-<?php echo e($user->id); ?>">
                                                                            <i class="fa fa-check-o"></i>Activate
                                                                        </button>
                                                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"  data-target="#delete-<?php echo e($user->id); ?>">
                                                                            <i class="fa fa-close"></i> Delete
                                                                        </button>
                                                                    <?php endif; ?>  
                                                                </td>
                                                            <?php endif; ?>      

                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                                </tbody>
                                        </table>
                                    </div>
                                <!-- END DATA TABLE-->
                            </div>
                    </div>
            </div>
        </div>
</div>
</main>

<div>
<!-- New Item Modal -->
<div class="modal fade" id="addNew">
    <div class="modal-dialog">
    <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"><i class="fa fa-user"></i> New user</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
    
        <!-- Modal body -->
        
        
        <div class="modal-body">    
            
            <?php echo Form::open(['action' => 'UserController@store', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <?php echo e(Form::label('firstname', 'First Name')); ?>

                    <?php echo e(Form::text('firstname', '', ['class' => 'form-control', 'placeholder' => 'First Name'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('lastname', 'Last Name')); ?>

                    <?php echo e(Form::text('lastname', '', ['class' => 'form-control', 'placeholder' => 'Last Name'])); ?>  
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('email', 'Email')); ?>

                    <?php echo e(Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

                    </div>
                <div class="form-group">
                    <?php echo e(Form::label('phonenumber', 'Mobile Number')); ?>

                    <?php echo e(Form::tel('phonenumber', '', ['class' => 'form-control', 'placeholder' => 'Phone Number'])); ?>

                </div>
                <div class="form-group">
                    <label for="role_id">Role</label>
                    <select  name="role_id" class="form-control" required>                                                                                
                        <option disabled selected value="0">None</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group row">
                    <?php echo e(Form::label('image', 'Profile Picture', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                    <div class="col-md-9">
                        <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                    </div>
                </div>                                 
                
                <div class="form-row">
                <?php echo e(Form::submit('Create', ['class' => 'btn btn-primary btn-block'])); ?>

                </div>

            <?php echo Form::close(); ?>

            
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
<div class="modal fade" id="deactivate-<?php echo e($user->id); ?>">
                    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  De-Activate User</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to de-activate <b><?php echo e($user->first_name.' '.$user->other_names); ?></b> ? </p>

                <?php echo Form::open(['action' => 'UserController@deactivate', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $user->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('De-activate', ['class' => 'btn btn-warning btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="activate-<?php echo e($user->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Activate Post</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to activate <b><?php echo e($user->first_name.' '.$user->other_names); ?></b> ? </p>

                <?php echo Form::open(['action' => 'UserController@activate', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $user->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Activate', ['class' => 'btn btn-success pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="delete-<?php echo e($user->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Delete Post</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to delete <b><?php echo e($user->first_name.' '.$user->other_names); ?> </b>? </p>

                <?php echo Form::open(['action' => 'UserController@delete', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $user->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

        <div class="modal fade" id="edit-<?php echo e($user->id); ?>">

        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Edit User</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">

                <?php echo Form::open(['action' => ['UserController@editUser', $user->id], 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

                <?php echo csrf_field(); ?>
                    
                <?php echo e(Form::hidden('id', $user->id)); ?>                    
                    <div class="form-group">
                        <?php echo e(Form::label('firstname', 'First Name')); ?>

                        <?php echo e(Form::text('firstname', $user->first_name, ['class' => 'form-control', 'placeholder' => 'First Name'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('lastname', 'Last Name')); ?>

                        <?php echo e(Form::text('lastname', $user->other_names, ['class' => 'form-control', 'placeholder' => 'Last Name'])); ?>  
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('email', 'Email')); ?>

                        <?php echo e(Form::email('email', $user->email, ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

                        </div>
                    <div class="form-group">
                        <?php echo e(Form::label('phonenumber', 'Mobile Number')); ?>

                        <?php echo e(Form::tel('phonenumber', $user->phone_number1, ['class' => 'form-control', 'placeholder' => 'Phone Number'])); ?>

                    </div>
                    <div class="form-group">
                            <label for="role_id">Role</label>
                            <select  name="role_id" class="form-control" required>                                                                                
                                <option value="<?php echo e($user->role->id); ?>"><?php echo e($user->role->name); ?></option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php if($role->name !== $user->role->name): ?>                                 
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>  

                    <div class="form-group row">
                        <?php echo e(Form::label('image', 'Featured Image', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                        <div class="col-md-9">
                            <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                        </div>
                    </div> 
                    
                    <div class="form-row">
                        <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary btn-block'])); ?>

                    </div>

                <?php echo Form::close(); ?>


                </div>
            </div>
            </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/admin/users.blade.php ENDPATH**/ ?>