<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="section__content section__content--p30">
    <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
        <a href="/manage">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Settings</li>
    </ol>

    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <div class="container">
            <div class="row">


            <div class="col-lg-12">
                <!-- settings -->
                <div class="card shadow mb-4">
                        <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary"> <i class="fa fa-user"></i> Personal Details</h6>
                        </div>
                        <div class="card-body">
                                <?php echo Form::open(['action' => ['UserController@update', Auth::user()->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>      
                                <?php echo csrf_field(); ?>
                                <?php echo e(Form::hidden('id', Auth::user()->id)); ?>    
                                <div class="form-row">
                                <div class="form-group col-md-3">
                                    <?php echo e(Form::label('firstname', 'First Name')); ?>

                                    <?php echo e(Form::text('firstname', Auth::user()->first_name, ['class' => 'form-control', 'placeholder' => 'First Name'])); ?>

                                    </div>
                                <div class="form-group col-md-3">
                                    <?php echo e(Form::label('lastname', 'Last Name')); ?>

                                    <?php echo e(Form::text('lastname', Auth::user()->other_names, ['class' => 'form-control', 'placeholder' => 'Last Name'])); ?>  
                                </div>
                                <div class="form-group col-md-3">
                                    <?php echo e(Form::label('email', 'Email')); ?>

                                    <?php echo e(Form::email('email', Auth::user()->email, ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

                                    </div>
                                <div class="form-group col-md-3">
                                    <?php echo e(Form::label('phonenumber', 'Mobile Number')); ?>

                                    <?php echo e(Form::tel('phonenumber', Auth::user()->phone_number1, ['class' => 'form-control', 'placeholder' => 'Phone Number'])); ?>

                                </div>
                                <div class="form-group col-md-4">
                                    <label for="avatar">Profile Picture</label>
                                    <input class="form-control btn-block <?php echo e($errors->has('avatar') ? ' is-invalid' : ''); ?>" type="file" name="image" accept="image/jpeg, image/jpg, image/png" onchange="readURL(this);">
                                    <?php if($errors->has('avatar')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('avatar')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                </div>


                                <div class="form-row">
                                <div class="col-md-12">
                                        <br>
                                <h5>Password Update</h5>
                                <br>
                                </div>
                                <div class="form-group col-md-4">
                                        <?php echo e(Form::label('oldpass', 'Old Password')); ?>

                                        <?php echo e(Form::password('oldpass', ['class' => 'form-control', 'placeholder' => '**********'])); ?>

                                    </div>
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('newpass', 'New Password')); ?>

                                    <?php echo e(Form::password('newpass', ['class' => 'form-control', 'placeholder' => '**********'])); ?>

                                </div>
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('cnewpass', 'Confirm New Password')); ?>

                                    <?php echo e(Form::password('cnewpass', ['class' => 'form-control', 'placeholder' => '**********'])); ?>

                                </div>
                                </div>  
                                
                                <?php echo e(Form::hidden('_method','PUT')); ?>    
                                <?php echo e(Form::submit('Update ', ['class'=>'btn btn-primary btn-block'])); ?>      <hr>
                                <?php echo Form::close(); ?>

                </div>
            </div>
    </div>
    
        
    </div>

    </div>
    </div>

    <script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#avatarthumb')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/admin/settings.blade.php ENDPATH**/ ?>