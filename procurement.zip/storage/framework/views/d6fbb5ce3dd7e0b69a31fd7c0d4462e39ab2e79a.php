<?php $__env->startSection('content'); ?>
<div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                        <div class="col-md-12">
                            <div class="overview-wrap">
                                <h2 class="title-1">Departments</h2>
                                <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addNew">
                                        <i class="fa fa-plus"></i>Add new
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                    <tr>                                                
                                                        <th>Image</th>                        
                                                        <th>Name</th>
                                                        <th></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr> 
                                                            <td style="width:100px">
                                                                    <?php if(!empty($department->image)): ?>
                                                                        <img  src="<?php echo e(asset( $department->image )); ?>" alt="<?php echo e($department->image); ?>" class="img-responsive"/>
                                                                    <?php endif; ?>
                                                            </td>
                                                            <td><?php echo e($department->name); ?></td>
                                                            <td>
                                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-<?php echo e($department->id); ?>">
                                                                    <i class="fa fa-edit"></i> Edit
                                                                </button>
                                                                <?php if($department->active): ?>
                                                                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal"  data-target="#deactivate-<?php echo e($department->id); ?>">
                                                                        <i class="fa fa-exclamation-triangle"></i> De-activate
                                                                    </button>
                                                                <?php else: ?>
                                                                    
                                                                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal"  data-target="#activate-<?php echo e($department->id); ?>">
                                                                        <i class="fa fa-check-o"></i>Activate
                                                                    </button>
                                                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"  data-target="#delete-<?php echo e($department->id); ?>">
                                                                        <i class="fa fa-close"></i> Delete
                                                                    </button>
                                                                <?php endif; ?>      
                                                    
                                                </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                            </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                    </div>
            </div>
        </div>
</div>
</main>
<div>
<!-- New Item Modal -->
<div class="modal fade" id="addNew">
    <div class="modal-dialog">
    <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"><i class="mdi mdi-format-list-bulleted menu-icon"></i> New department</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
    
        <!-- Modal body -->
        
        
        <div class="modal-body">    
            
            <?php echo Form::open(['action' => 'DepartmentController@create', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

            <?php echo csrf_field(); ?>
                
                <div class="form-group">
                <?php echo e(Form::label('name', 'Name')); ?>

                <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'e.g Administration','required'])); ?>

                </div>    

                <div class="form-group row">
                    <?php echo e(Form::label('image', 'Featured Image', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                    <div class="col-md-9">
                        <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                    </div>
                </div>                                 
                
                <div class="form-row">
                <?php echo e(Form::submit('Create', ['class' => 'btn btn-primary btn-block'])); ?>

                </div>

            <?php echo Form::close(); ?>

            
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
<div class="modal fade" id="deactivate-<?php echo e($department->id); ?>">
                    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  De-Activate Department</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to de-activate <b><?php echo e($department->name); ?></b> ? </p>

                <?php echo Form::open(['action' => 'DepartmentController@deactivate', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $department->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('De-activate', ['class' => 'btn btn-warning btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="activate-<?php echo e($department->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Activate Department</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to activate <b><?php echo e($department->name); ?></b> ? </p>

                <?php echo Form::open(['action' => 'DepartmentController@activate', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $department->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Activate', ['class' => 'btn btn-success pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="delete-<?php echo e($department->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Delete Department</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to delete <b><?php echo e($department->name); ?> </b>? </p>

                <?php echo Form::open(['action' => 'DepartmentController@destroy', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $department->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

        <div class="modal fade" id="edit-<?php echo e($department->id); ?>">

        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Edit Category</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">

                <?php echo Form::open(['action' => 'DepartmentController@edit', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

                <?php echo csrf_field(); ?>
                    
                <?php echo e(Form::hidden('id', $department->id)); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('name', 'Name')); ?>

                        <?php echo e(Form::text('name', $department->name, ['class' => 'form-control', 'placeholder' => 'e.g FRUITS','required'])); ?>

                    </div>  

                    <div class="form-group row">
                        <?php echo e(Form::label('image', 'Featured Image', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                        <div class="col-md-9">
                            <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                        </div>
                    </div> 
                    
                    <div class="form-row">
                        <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary btn-block'])); ?>

                    </div>

                <?php echo Form::close(); ?>


                </div>
            </div>
            </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/admin/departments.blade.php ENDPATH**/ ?>