<?php $__env->startSection('content'); ?>
<div class="main-content">
        <div class="section__content section__content--p30">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="overview-wrap">
                                <h2 class="title-1">Quotes</h2>
                                <?php if(Auth::user()->role->id <= 2): ?>
                                    <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addNew">
                                            <i class="fa fa-plus"></i>Add new
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <tr>                                                
                                                    <th>Amount</th>
                                                    <th>Desc</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tr>
                                        </thead>                                        
                                        <tbody>
                                            <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>      
                                                    <?php if(count($quote->quoteItems)): ?>
                                                        <td><?php echo e('Ksh '.number_format($quote->quoteItems->sum('price'))); ?></td>
                                                    <?php else: ?>
                                                        <td>---</td>
                                                    <?php endif; ?>                                      
                                                    <td><?php echo e(substr(strip_tags($quote->desc), 0, 50)); ?><?php echo e(strlen(strip_tags($quote->desc)) > 50 ? "..." : ""); ?></td>
                                                    <td><?php echo e(date('M j, Y', strtotime($quote->created_at))); ?></td>
                                                    <?php if($quote->status == 0): ?>
                                                        <td class="text-info"><i class="fa fa-spinner"> Pending</td>
                                                    <?php elseif($quote->status == 1): ?>
                                                        <td class="text-danger"><i class="fa fa-close"> Declined</td>
                                                    <?php elseif($quote->status == 2): ?>
                                                        <td class="text-success"><i class="fa fa-check-circle"></i> Approved</td>
                                                    
                                                    <?php endif; ?>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">                                                    
                                                                
                                                                <?php if(Auth::user()->role->id <= 2): ?>
                                                                    <?php if($quote->status == 0): ?>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#decline-<?php echo e($quote->id); ?>">Decline</a>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#approve-<?php echo e($quote->id); ?>">Approve</a>
                                                                    
                                                                    <?php endif; ?>
                                                                    <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#delete-<?php echo e($quote->id); ?>">Delete</a>
                                                                <?php endif; ?>
                                                                <?php if(Auth::user()->role->id == 3 && $quote->status == 2): ?>
                                                                    <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#bid-<?php echo e($quote->id); ?>">Bid</a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                            </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                    </div>
            </div>
        </div>
</div>
</main>

<div>

<!-- New Item Modal -->
<div class="modal fade" id="addNew">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"><i class="mdi mdi-format-list-bulleted menu-icon"></i> New Quote</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
    
        <!-- Modal body -->
        
        
        <div class="modal-body">    
            
            <?php echo Form::open(['action' => 'QuoteController@create', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

            <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <?php echo e(Form::label('department_id', 'Department')); ?>

                    <select  name="department_id" class="form-control select2" required>                                        
                        <option disabled selected value="0">--Select--</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                  
                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>    

                <div class="form-group">
                    <?php echo e(Form::label('description', 'Description')); ?>

                    <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => '...','rows' => '5', ''])); ?>

                </div> 
                
                <br>
                <h4 class="text-center">Items</h4>  
                <hr>
                <?php
                    $others= 0;
                ?>
                <?php while($others <5): ?>
                    <div class="form-row">
                        <div class="col-md-4">
                            <?php echo e(Form::label('qty', 'Quantity')); ?>

                            <?php echo e(Form::number('qty[]', '', ['class' => 'form-control'])); ?>   
                        </div>                                
                        <div class="col-md-4">
                            <?php echo e(Form::label('unit', 'Unit')); ?>

                            <?php echo e(Form::text('unit[]', '', ['class' => 'form-control'])); ?>   
                        </div>                        
                        <div class="col-md-4">
                            <?php echo e(Form::label('price', 'Unit Price')); ?>

                            <?php echo e(Form::number('price[]', '', ['class' => 'form-control'])); ?> 
                        </div>                        
                        <div class="col-md-12">
                            <?php echo e(Form::label('desc', 'Description')); ?>

                            <?php echo e(Form::textarea('desc[]', '', ['class' => 'form-control', 'placeholder' => '...', 'rows' => '3'])); ?> 
                        </div>
                    </div>  
                    <hr>                        
                    <?php
                        $others++;           
                    ?>
                <?php endwhile; ?>  
                <br>
                
                <div class="form-row">
                    <?php echo e(Form::submit('Create', ['class' => 'btn btn-primary btn-block'])); ?>

                </div>

            <?php echo Form::close(); ?>

            
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- New Item Modal -->
    <div class="modal fade" id="bid-<?php echo e($quote->id); ?>">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="mdi mdi-format-list-bulleted menu-icon"></i> New Bid</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
        
            <!-- Modal body -->
            
            
            <div class="modal-body">    
                
                <?php echo Form::open(['action' => 'BidController@create', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

                <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <?php echo e(Form::label('amount', 'Amount')); ?>

                        <?php echo e(Form::number('amount', '', ['class' => 'form-control', 'placeholder' => '...', 'required'])); ?>

                    </div>    

                    <div class="form-group">
                        <?php echo e(Form::label('message', 'Message')); ?>

                        <?php echo e(Form::textarea('message', '', ['class' => 'form-control', 'placeholder' => '...','rows' => '5', ''])); ?>

                    </div> 
                    <br>
                    <?php echo e(Form::hidden('quote_id', $quote->id)); ?>


                    <div class="form-row">
                        <?php echo e(Form::submit('Create', ['class' => 'btn btn-primary btn-block'])); ?>

                    </div>

                <?php echo Form::close(); ?>

                
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="decline-<?php echo e($quote->id); ?>">
                                                        
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"><i class="fa fa-quote-left"></i>  Decline quote</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->


                <div class="modal-body">
                    <p>Are you sure you want to Decline this Quote</b> ? </p>

                    <?php echo Form::open(['action' => 'QuoteController@decline', 'method' => 'POST']); ?>

                    <?php echo csrf_field(); ?>                               
                    
                        <?php echo e(Form::hidden('id', $quote->id)); ?>

                        
                    <div class="form-row">
                        <?php echo e(Form::submit('Decline', ['class' => 'btn btn-warning btn-block'])); ?>

                        <?php echo Form::close(); ?>

                    </div>       
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="approve-<?php echo e($quote->id); ?>">

        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-quote-left"></i>  Approve Quote</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->


                <div class="modal-body">
                    <p>Are you sure you want to approve this Quote ? </p>

                    <?php echo Form::open(['action' => 'QuoteController@approve', 'method' => 'POST']); ?>

                    <?php echo csrf_field(); ?>                               
                    
                        <?php echo e(Form::hidden('id', $quote->id)); ?>

                        
                    <div class="form-row">
                        <?php echo e(Form::submit('Approve', ['class' => 'btn btn-success pull-right btn-block'])); ?>

                        <?php echo Form::close(); ?>

                    </div>       
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="delete-<?php echo e($quote->id); ?>">

        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"><i class="fa fa-quote-left"></i>  Delete quote</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->


                <div class="modal-body">
                    <p>Are you sure you want to delete this Quote? </p>

                    <?php echo Form::open(['action' => 'QuoteController@destroy', 'method' => 'POST']); ?>

                    <?php echo csrf_field(); ?>                               
                    
                        <?php echo e(Form::hidden('id', $quote->id)); ?>

                        
                    <div class="form-row">
                        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger pull-right btn-block'])); ?>

                        <?php echo Form::close(); ?>

                    </div>       
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/admin/quotes.blade.php ENDPATH**/ ?>