<?php $__env->startSection('content'); ?>
<div class="main-content">
        <div class="section__content section__content--p30">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <div class="container-fluid">
                <div class="row">
                        <div class="col-md-12">
                            <div class="overview-wrap">
                                <h2 class="title-1">Bids</h2>
                                
                            </div>
                        </div>
                    </div>
                    <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>                                                
                                                <th>Date</th>                        
                                                <th>Supplier</th>
                                                <th>Amount</th>
                                                <th>Message</th>
                                                <th>Status</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(date('M j, Y', strtotime($bid->created_at))); ?></td>
                                                    <td><?php echo e($bid->Supplier->first_name.' '.$bid->Supplier->other_names); ?></td>
                                                    <td><?php echo e('Ksh. '. number_format($bid->amount)); ?></td>
                                                    <td><?php echo e(substr(strip_tags($bid->message), 0, 50)); ?><?php echo e(strlen(strip_tags($bid->message)) > 50 ? "..." : ""); ?></td>
                                                    <?php if($bid->status == 0): ?>
                                                        <td class="text-info"><i class="fa fa-spinner"> Pending</td>
                                                    <?php elseif($bid->status == 1): ?>
                                                        <td class="text-danger"><i class="fa fa-close"> Denied</td>
                                                    <?php elseif($bid->status == 2): ?>
                                                        <td class="text-success"><i class="fa fa-check-circle"></i> Awarded</td>
                                                    <?php endif; ?>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">                                                    
                                                                
                                                                <?php if(Auth::user()->role->id <= 2): ?>
                                                                    <?php if($bid->status == 0): ?>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#deny-<?php echo e($bid->id); ?>">Deny</a>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#award-<?php echo e($bid->id); ?>">Award</a>
                                                                    <?php endif; ?>
                                                                    <?php if($bid->status == 1): ?>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#comments-<?php echo e($bid->id); ?>">Comments</a>
                                                                    <?php endif; ?>
                                                                        <a class="dropdown-item" href="#" data-toggle="modal"  data-target="#delete-<?php echo e($bid->id); ?>">Delete</a>
                                                                <?php endif; ?>
                                                                
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                            </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                    </div>
            </div>
        </div>
</div>
</main>
<div>
<!-- New Item Modal -->
<div class="modal fade" id="addNew">
    <div class="modal-dialog">
    <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
            <h4 class="modal-title"><i class="mdi mdi-format-list-bulleted menu-icon"></i> New bid</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
    
        <!-- Modal body -->
        
        
        <div class="modal-body">    
            
            <?php echo Form::open(['action' => 'BidController@create', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

            <?php echo csrf_field(); ?>
                
                <div class="form-group">
                <?php echo e(Form::label('name', 'Name')); ?>

                <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'e.g Sermons','required'])); ?>

                </div>    

                <div class="form-group row">
                    <?php echo e(Form::label('image', 'Featured Image', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                    <div class="col-md-9">
                        <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                    </div>
                </div>                                 
                
                <div class="form-row">
                <?php echo e(Form::submit('Create', ['class' => 'btn btn-primary btn-block'])); ?>

                </div>

            <?php echo Form::close(); ?>

            
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
    <div class="modal fade" id="comments-<?php echo e($bid->id); ?>">
                
            <div class="modal-dialog">
                <div class="modal-content">
            
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"><i class="fa fa-comments"></i>  Comments</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->
            
            
                <div class="modal-body">
                    <div class="col-md-12">
                        <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
                            <table class="table table-borderless table-data3">
                                <thead>
                                    <tr>                                                
                                        <th>Date</th>                        
                                        <th>Comment</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bid->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(date('M j, Y', strtotime($comment->created_at))); ?></td>
                                                <td><?php echo e(substr(strip_tags($comment->comment), 0, 100)); ?><?php echo e(strlen(strip_tags($comment->comment)) > 100 ? "..." : ""); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
<div class="modal fade" id="deny-<?php echo e($bid->id); ?>">
                    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Deny Bid</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to deny <b>Bid</b> ? </p>

                <?php echo Form::open(['action' => 'BidController@deny', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $bid->id)); ?>

                <br>
                <div class="form-group">
                    <?php echo e(Form::label('comment', 'Comment')); ?>

                    <?php echo e(Form::textarea('comment', '', ['class' => 'form-control', 'placeholder' => '...','rows' => '5', 'required'])); ?>

                </div> 
                    
                <div class="form-row">
                <?php echo e(Form::submit('Deny', ['class' => 'btn btn-warning btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="award-<?php echo e($bid->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Award Bid</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to award <b>bid</b> ? </p>

                <?php echo Form::open(['action' => 'BidController@award', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $bid->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Award', ['class' => 'btn btn-success pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

    <div class="modal fade" id="delete-<?php echo e($bid->id); ?>">
    
        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Delete Bid</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">
                <p>Are you sure you want to delete <b><?php echo e($bid->name); ?> </b>? </p>

                <?php echo Form::open(['action' => 'BidController@destroy', 'method' => 'POST']); ?>

                <?php echo csrf_field(); ?>                               
                
                <?php echo e(Form::hidden('id', $bid->id)); ?>

                    
                <div class="form-row">
                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger pull-right btn-block'])); ?>

                <?php echo Form::close(); ?>

                </div>       
            </div>
        </div>
        </div>
    </div>

        <div class="modal fade" id="edit-<?php echo e($bid->id); ?>">

        <div class="modal-dialog">
            <div class="modal-content">
        
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="fa fa-users"></i>  Edit bid</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
        
        
            <div class="modal-body">

                <?php echo Form::open(['action' => 'BidController@edit', 'method' => 'POST', 'data-parsley-validate' => '', 'files' => true]); ?>

                <?php echo csrf_field(); ?>
                    
                <?php echo e(Form::hidden('id', $bid->id)); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('name', 'Name')); ?>

                        <?php echo e(Form::text('name', $bid->name, ['class' => 'form-control', 'placeholder' => 'e.g FRUITS','required'])); ?>

                    </div>  

                    <div class="form-group row">
                        <?php echo e(Form::label('image', 'Featured Image', array('class' => 'col-md-3 col-form-label', 'for' => 'file-input'))); ?>                                
                        <div class="col-md-9">
                            <?php echo e(Form::file('image', ['id' => 'file-input'])); ?>                                   
                        </div>
                    </div> 
                    
                    <div class="form-row">
                        <?php echo e(Form::submit('Update', ['class' => 'btn btn-primary btn-block'])); ?>

                    </div>

                <?php echo Form::close(); ?>


                </div>
            </div>
            </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/admin/bids.blade.php ENDPATH**/ ?>