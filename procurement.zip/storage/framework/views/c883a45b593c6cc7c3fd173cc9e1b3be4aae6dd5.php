<?php $__env->startSection('auth-content'); ?>
<body class="animsition">
        <div class="page-wrapper">
            <div class="page-content--bge5">
                <div class="container">
                    <div class="login-wrap">
                        <div class="login-content">
                            <div class="login-logo">
                                
                                    <h2>Procurement</h2>
                                
                            </div>
                            <div class="login-form">
                                <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                            <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label><?php echo e(__('E-Mail Address')); ?></label>
                                        <input class="au-input au-input--full<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" required autofocus" type="email" name="email" placeholder="Email">
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo e(__('Password')); ?></label>
                                        <input class="au-input au-input--full <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required type="password" name="password" placeholder="Password">
                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="login-checkbox">
                                        <label>
                                            <input type="checkbox" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                        <label>
                                            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
                                        </label>
                                    </div>
                                    <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit"><?php echo e(__('Login')); ?></button>                                    
                                </form>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\procurement\resources\views/auth/login.blade.php ENDPATH**/ ?>